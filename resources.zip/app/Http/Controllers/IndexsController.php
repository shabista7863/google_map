<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB; 
//use Session;
class IndexsController extends Controller
{
    public function videoInsert()
    {
        //$video = DB::table('video_uploaded')->where('id')->pluck('video');
        $videos = DB::table('video_uploaded')->select('*')->get();
      
        return view('reg/index')->with('videos',$videos);
    }
}
