
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Bootstrap Example</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<style>
.btncls{
 background-color:#498694;    width: 100px;
}
.txtcolor{
  color:#498694;
}
.backbtn{
  background-color: #498694;
    padding: 4px;
    color: #fff;
    width: 60px;
    text-align: center;
}
.custable th{
	font-size: 14px;
    font-weight: 600;
}
.custable td{
	font-size: 14px;
}
</style>


</head>

<body style="background-color: #e0dddd;">

<div class="container">

<p align="right"><a  href="<?php echo e(url('userVideos')); ?>" class="btn btn-info btn-sm mt-3" >
		<span  class="glyphicon glyphicon-log-out btncls" ></span>Back
	</a>
</p>
<div class="welcometxtcls">
<h1 class="text-center mt-4 txtcolor">Video Lists</h1>
</div>
           
	<table class="custable table table-condensed table-bordered p-4 bg-white">
		<thead>
			<tr>
			
				<th>Sno.</th> 
				<th>Video_type</th>
				<th>Video_url</th>
				<th>Video_price</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
		<?php //dd($users);?>
		<?php $i = 0; ?>
	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
 
		<!-- $id=$usr['id'];
		 -->
        <tr>
		<td><?php echo e($i); ?></td>
		<?php $i++; ?>
        <td><?php echo e($usr->video_type); ?> </td>
        <td><?php echo e($usr->video_url); ?> </td>
		<td><?php echo e($usr->price); ?> </td>
        <td>
            <a type="button" class="btn btn-sm btn-info" href="<?php echo e(url('userVideos',$usr->id)); ?>" >
                Update
            </a>
            <a type="button" class="btn btn-sm btn-danger" href="<?php echo e(url('reg/video_list')); ?>">Delete
            </a>
        </td> 
      </tr>

	 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tr>
		</tbody>
	</table>
</div>


</body>
</html>
<?php /**PATH D:\Xampp\htdocs\secondAssignment\resources\views/reg/video_list.blade.php ENDPATH**/ ?>