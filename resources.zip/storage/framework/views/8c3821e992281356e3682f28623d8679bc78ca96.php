<?php //dd($Name);?>
<html>
<head> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<style>
.btncls{
 background-color:#498694;    width: 100px;
}
.txtcolor{
  color:#498694;
}
.backbtn{
  background-color: #498694;
    padding: 4px;
    color: #fff;
    width: 60px;
    text-align: center;
}
.welcometxtcls h1 {
    font-size: 30px !important;
    color: #498694;
    border-color: #498694 !important;

}
</style>
</head>

<body>
<body style="background-color: #e0dddd;">
<div class="container">
<a href="index.php"  class="float-right backbtn">Back</a>
<div class="welcometxtcls">
<h1 class="text-center mt-4 txtcolor">SignUp Form</h1>
</div>

<form method = "POST" action="<?php echo e(url('userRgis')); ?>" class="p-4 w-50 mx-auto border mt-4 bg-white">
<?php echo e(csrf_field()); ?>


 <?php if(count($errors)): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<?php //dd($success);?>
<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?> 


  <div class="form-group">
 
  <label for="exampleInputEmail1">Name</label>
  <input type="name" class="form-control <?php echo e($errors->has('name') ? 'has-error' : ''); ?>" value="<?php echo e(old('name')); ?>" id="exampleInputEmail1" aria-describedby="emailHelp"  name="name" placeholder="Enter name"><br><br>
  <span class="text-danger"><?php echo e($errors->first('name')); ?></span>

  <label for="exampleInputEmail1">Email</label>
  <input type="email" class="form-control <?php echo e($errors->has('email') ? 'has-error' : ''); ?>" value="<?php echo e(old('email')); ?>" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" placeholder="Enter email"><br><br>
  <span class="text-danger"><?php echo e($errors->first('email')); ?></span>

  <label for="exampleInputEmail1">Phone no</label>
  <input type="text" class="form-control <?php echo e($errors->has('phone_no') ? 'has-error' : ''); ?>" value="<?php echo e(old('phone_no')); ?>" id="exampleInputEmail1" aria-describedby="emailHelp" name="phone_no" placeholder="Enter phoneNo"><br><br>
   <span class="text-danger"><?php echo e($errors->first('phone_no')); ?></span>

  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="text" class="form-control <?php echo e($errors->has('Password') ? 'has-error' : ''); ?>" value="<?php echo e(old('Password')); ?>" id="exampleInputPassword1" name="password" placeholder="Enter password"><br><br>
   <span class="text-danger"><?php echo e($errors->first('Password')); ?></span>

  </div>
  
  <button type="submit" class="btn btn-primary btncls">Submit</button>
  </div>
  </body>
</form>
</html><?php /**PATH D:\Xampp\htdocs\secondAssignment\resources\views/reg/signup.blade.php ENDPATH**/ ?>