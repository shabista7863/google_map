<?php //dd($Name);?>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<style>
.btncls{
 background-color:#498694;    width: 100px;
}
.txtcolor{
  color:#498694;
}
.backbtn{
  background-color: #498694;
    padding: 4px;
    color: #fff;
    width: 60px;
    text-align: center;
}
.welcometxtcls h1 {
    font-size: 30px !important;
    color: #498694;
    border-color: #498694 !important;

}
</style>
</head>
<body style="background-color: #e0dddd;">
<div class="container">
<a href="index.php"  class="float-right backbtn">Back</a>
<div class="welcometxtcls">
<h1 class="text-center mt-4 txtcolor">LogIn Form</h1>
</div>



<form method = "POST" action="<?php echo e(url('userLogin')); ?>" class="p-4 w-50 mx-auto border mt-5 bg-white">
<?php echo e(csrf_field()); ?>



<!-- <?php if(count($errors)): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<?php //dd($success);?>
<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>  -->


  <div class="form-group">
 
  <label for="exampleInputEmail1">Email</label>
  <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" placeholder="Enter email" value=""><br><br>
  
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="Enter password" value=""><br><br>
  </div>
  
  <button type="submit" class="btn btn-primary btncls">Login</button>
  <a href="" class="forgotpwd">Forgot Password?</a>
  </div>
</body>
</form>
</html><?php /**PATH D:\Xampp\htdocs\secondAssignment\resources\views/reg/signin.blade.php ENDPATH**/ ?>