<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('reg/index');
// });

Route::get('/signup', 'RegistersController@create');
Route::post('/userRgis', 'RegistersController@insert');
Route::post('/userRgis', 'RegistersController@store');

Route::get('/signin', 'LoginsController@signin');
Route::post('/userLogin', 'LoginsController@view');
Route::get('/logout', 'LoginsController@logout');
Route::get('/reg/dashboard', 'VideosController@dashboard');

Route::get('/userVideos', 'VideosController@create');
Route::post('/userVideos', 'VideosController@insert');
//Route::post('/userVideos', 'VideosController@validation');

Route::get('/reg/video_list', 'VideosController@videolist');
Route::get('/userVideos/{id}', 'VideosController@edit');
Route::get('/', 'IndexsController@videoInsert');