<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home page</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<style>
.loginlist li {
    list-style-type: none;
    display: inline-block;
    padding-left: 10px;
    background-color: #498694;
    padding: 6px;
    border-radius: 4px;
   
}

.loginlist li a { font-size: 15px;
    text-decoration: none;
}
.welcometxt h1 {
    font-size: 50px !important;
    color: #498694;
    border-color: #498694 !important;

}
.homelist li {
    min-width: 260px !important;
    list-style-type: none;
    /* height: 200px; */
    margin-left: 10px;
    text-align: center;
    min-height: 20px;
    padding: 19px;
    margin-bottom: 20px;
    background-color: #f5f5f5;
    border: 1px solid #e3e3e3;
    border-radius: 4px;
}
.homelist li a {
    color: #498694;
    font-size: 16px;
    text-decoration:none;
}
.price{ text-align position:absolute}

.upperheader {
    background-color: #e0dddd;
}
</style>
</head>
<body>
    <div class="upperheader">
    <div class="container">
    <div class="row">
    <div class="offset-md-6 col-md-6 ">
    <ul class="loginlist float-right m-4">
    <li><a href="signin" class="text-white">Login</a></li>
    <li><a href="signup"  class="text-white">Registration</a></li>
    </ul>
    </div>
    </div>
<div class="row mt-5">
    <div class="col-md-12">
    <div class="welcometxt mt-5">
    
    <h1 class="text-center border-bottom"> WELCOME TO LARAVEL</h1>
    </div>
   </div>

    </div>

    <ul class="row mt-5 homelist">

    @foreach($videos as $vdo)
    <?php //echo $vdo->video; die;?>
    <li class="">  
    <video width="400" controls>
  <source src="https://www.w3schools.com/html/mov_bbb.mp4" type="video/mp4">
  <source src="mov_bbb000.ogg" type="video/ogg">
  Your browser does not support HTML5 video.
</video>
     <video  controls>
         <?php 
            $url  = Storage::disk('local')->url('uploaded_videos/'.$vdo->video);
            $file_path = \Storage::url('sampleVideo_1280x720_1mb.mp4');
            $url = asset('sampleVideo_1280x720_1mb.mp4'); 
        ?>
     <source src="<?php echo $url;?>" type="video/mp4">
     <!-- <source src="#" type="video/ogg"> --> 
     </video> 
    <div class="video-content">
    <span class="price">Rs. {{$vdo->price}}</span> <br>
     <span class="title"> <b>{{$vdo->video_type}}</b> </span>
     </div>
     </li>

     @endforeach

    </ul>
    </div>
    </div>




    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>