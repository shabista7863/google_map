<?php //dd($Name);?>
<html>
<head> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<style>
.btncls{
 background-color:#498694;    width: 100px;
}
.txtcolor{
  color:#498694;
}
.backbtn{
  background-color: #498694;
    padding: 4px;
    color: #fff;
    width: 60px;
    text-align: center;
}
.welcometxtcls h1 {
    font-size: 30px !important;
    color: #498694;
    border-color: #498694 !important;

}
</style>
</head>

<body>
<body style="background-color: #e0dddd;">
<div class="container">
<a href="index.php"  class="float-right backbtn">Back</a>
<div class="welcometxtcls">
<h1 class="text-center mt-4 txtcolor">Forgot password</h1>
</div>
<form action="" class="forgotpwd p-4 w-50 mx-auto border mt-4 bg-white">
<input type="password" name="" id="" placeholder="Old Password">
<input type="password" name="" id="" placeholder="New Password">
<input type="button" value="Change Password" class="btn btn-primary btncls">
</form>
</html>